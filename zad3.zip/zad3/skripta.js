
const countryElement = document.getElementById("country");

const storedCountry = sessionStorage.getItem("country");
if (storedCountry) {
    countryElement.textContent = storedCountry;
} else {
   
    const apiKey = "8afa66c7ffc85d160ad9b42e407d925c"; 
    const apiUrl = `http://api.ipstack.com/check?access_key=${apiKey}`;
    
    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            const countryName = data.country_name;
            
            sessionStorage.setItem("country", countryName);
           
            countryElement.textContent = countryName;
        })
        .catch(error => {
            countryElement.textContent = "Country not found";
            console.error("Error fetching geolocation data:", error);
        });
}
