const button = document.querySelector(".gumb");
const tekst = document.querySelector(".paragraf");
button.addEventListener("click", onClick);

function onClick() {
    const data = tekst.getAttribute("aria-hidden");
    if(data === "true"){
        tekst.setAttribute("aria-hidden", "false")
    }
    else{
        tekst.setAttribute("aria-hidden", "true")
    }
}